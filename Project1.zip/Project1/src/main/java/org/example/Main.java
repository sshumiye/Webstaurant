package org.example;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
        WebDriver driver = new ChromeDriver();
        try {
            // 1. Go to the website
            driver.get("https://www.webstaurantstore.com/");

            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
            driver.manage().window().maximize();
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("searchval")));
            // 2. Search for 'stainless work table'
            driver.findElement(By.id("searchval")).sendKeys("stainless work table");
            driver.findElement(By.cssSelector("button[type='submit']")).click();


            wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".ag-item")));

            // 3. Check search results
            List<WebElement> items = driver.findElements(By.cssSelector(".ag-item"));
            boolean allItemsValid = true;

            for (WebElement item : items) {
                String title = item.getText();
                if (!title.contains("Table")) {
                    allItemsValid = false;
                    System.out.println("Found an item without 'Table' in the title: " + title);
                    break;
                }
            }

            if (allItemsValid) {
                System.out.println("All items have 'Table' in the title.");
            }

            // 4. Add the last found item to Cart
            if (!items.isEmpty()) {
                items.get(items.size() - 1).click();
                wait.until(ExpectedConditions.elementToBeClickable(By.name("addToCartButton")));
                driver.findElement(By.name("addToCartButton")).click();
            }
            // 1. Go to cart page
            driver.get("https://www.webstaurantstore.com/cart/");
            // 5. Empty Cart
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".emptyCartButton")));
            driver.findElement(By.cssSelector(".emptyCartButton")).click();
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@role='alertdialog']")));
            driver.findElement(By.xpath("//div[@role='alertdialog']/div/footer/button[1]")).click();
            System.out.println("Test completed successfully.");
            driver.quit();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            driver.quit();
        }
    }
}